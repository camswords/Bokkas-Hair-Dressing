package controllers;

import play.mvc.Controller;

public class AreasAndHours extends Controller {
	
	public static void index() {
		render();
	}
}
