package controllers;

import play.mvc.Controller;

public class Contact extends Controller {
	
	public static void index() {
		render();
	}

}
