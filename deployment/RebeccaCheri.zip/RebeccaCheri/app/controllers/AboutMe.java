package controllers;

import play.mvc.Controller;

public class AboutMe extends Controller {
	
	public static void index() {
		render();
	}

}
